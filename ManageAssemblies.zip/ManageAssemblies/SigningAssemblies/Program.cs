﻿
using RegularAssembly;
using System;

namespace SigningAssemblies
{
    class Program
    {
        static void Main(string[] args)
        {
            MyClass myClass = new MyClass();
            Console.WriteLine("Hello World!");
            Console.Read();
        }
    }
}
